<h2><strong><?php print $text; ?></strong></h2>
